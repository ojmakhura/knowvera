import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTabsModule } from '@angular/material/tabs';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  computed,
  Component,
  effect,
  inject,
  Input,
  linkedSignal,
  OnDestroy,
  OnInit,
  signal,
} from '@angular/core';
import { form, required, applyEach, FormField, min, minLength, FormRoot } from '@angular/forms/signals';
import { DocumentTypeDTO } from '@app/models/bw/co/knowvera/document/type/document-type-dto';
import { KeyField } from '@app/models/bw/co/knowvera/key-field';
import { DocumentTypeApiStore } from '@app/store/bw/co/knowvera/document/type/document-type-api.store';
import { swalFire } from '@app/@shared/swal';
import { Loader } from '@app/@shared/loader/loader';
import { TranslateModule } from '@ngx-translate/core';
import { ExpectedFieldDTO } from '@app/models/bw/co/knowvera/document/type/field/expected-field-dto';
import { VerificationDataConfigDTO } from '@app/models/bw/co/knowvera/document/type/verification/verification-data-config-dto';
import { toast } from 'ngx-sonner';
import { ExpectedFieldType } from '@app/models/bw/co/knowvera/document/type/field/expected-field-type';
import { TargetEntity } from '@app/models/bw/co/knowvera/target-entity';
import { IndividualDTO } from '@app/models/bw/co/knowvera/individual/individual-dto';
import { OrganisationDTO } from '@app/models/bw/co/knowvera/organisation/organisation-dto';
import { KycInvoiceDTO } from '@app/models/bw/co/knowvera/invoice/kyc-invoice-dto';
import { KycRecordDTO } from '@app/models/bw/co/knowvera/kyc/kyc-record-dto';
import { ContactDTO } from '@app/models/bw/co/knowvera/contact/contact-dto';
import { SettingsDTO } from '@app/models/bw/co/knowvera/settings/settings-dto';
import { DocumentDTO } from '@app/models/bw/co/knowvera/document/document-dto';
import { ExpectedFieldApiStore } from '@app/store/bw/co/knowvera/document/type/field/expected-field-api.store';
import { VerificationDataConfigApiStore } from '@app/store/bw/co/knowvera/document/type/verification/verification-data-config-api.store';
import { VerificationDataConfigApi } from '@app/services/bw/co/knowvera/document/type/verification/verification-data-config-api';
import { TimePeriod } from '@app/models/bw/co/knowvera/time-period';
import { LoaderState } from '@app/@shared/loader/loader.state';
import { DocumentTypeApi } from '@app/services/bw/co/knowvera/document/type/document-type-api';
import { ProcessingProfile } from '@app/models/bw/co/knowvera/document/type/processing-profile';
import { DataProcessor, DataProcessorField } from '@app/models/bw/co/knowvera/document/type/data-processor';

export class EditDocumentTypeVarsForm {
  id: string | any = null;
  createdAt: Date | any = null;
  createdBy: string | any = null;
  modifiedAt: Date | any = null;
  modifiedBy: string | any = null;
  // Native text inputs bound with [formField] must start as '' — signal forms treats a null
  // model value on <input type="text"> as numeric and rejects non-numeric input.
  code: string | any = '';
  name: string | any = '';
  description: string | any = null;
  processingProfileCode: string | any = '';
  dataProcessorId: string | any = '';
  expires: boolean | any = false;
  expiryField: KeyField | any = null;
  expiryPeriod: TimePeriod | any;
expiresIn: number | any;
  expectedFields: Array<ExpectedFieldDTO> = [];
  verificationDataConfigs: VerificationDataConfigDTO[] = [];
}

@Component({
  selector: 'app-document-type-edit',
  templateUrl: './document-type-edit.html',
  styleUrls: ['./document-type-edit.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatTabsModule,
    FormField,
    TranslateModule,
    FormRoot,
  ],
})
export class DocumentTypeEdit implements OnInit, AfterViewInit, OnDestroy {
  @Input() id: string = '';
  protected readonly keyFieldOptions = Object.values(KeyField);
  protected readonly timePeriodOptions = Object.values(TimePeriod);
  // protected readonly verificationTagOptions = Object.values(VerificationTag);
  protected readonly expectedFieldIndex = signal(0);
  protected readonly verificationDataConfigIndex = signal(0);

  editDocumentTypeVarsForm: EditDocumentTypeVarsForm = new EditDocumentTypeVarsForm();
  editDocumentTypeSignal = signal(this.editDocumentTypeVarsForm);
  editDocumentTypeSignalForm = form(this.editDocumentTypeSignal, (path) => {
    required(path.code, { message: 'code.required' });
    required(path.name, { message: 'name.required' });

    if (this.editDocumentTypeSignal().expectedFields.length > 1) {
      applyEach(path.expectedFields, (fieldPath) => {
        // required(fieldPath.keyField, { message: 'keyField.required' });
        required(fieldPath.mandatory, { message: 'mandatory.required' });
        required(fieldPath.field, { message: 'field.required' });
      });
    }

    // if(this.editDocumentTypeSignal().verificationDataConfigs.length > 0) {

    // applyEach(path.verificationDataConfigs, (configPath) => {
    //   required(configPath.name, { message: 'verificationDataConfig.name.required' });
    //   minLength(path.expectedFields, 1, { message: 'verificationDataConfig.expectedFields.min' });
    // });
    // }
  }, { submission: { action: async () => this.saveDocumentType() } });

  documentTypeApiStore = inject(DocumentTypeApiStore);

  loading = linkedSignal(() => this.documentTypeApiStore.loading());
  loaderMessage = linkedSignal(() => this.documentTypeApiStore.loaderMessage());
  success = linkedSignal(() => this.documentTypeApiStore.success());
  error = linkedSignal(() => this.documentTypeApiStore.error());
  messages = linkedSignal(() => this.documentTypeApiStore.messages());

  // toastr = inject(ToastrService);
  dialog = inject(MatDialog);
  expectedFieldApiStore = inject(ExpectedFieldApiStore);
  verificationConfigApiStore = inject(VerificationDataConfigApiStore);
  verificationConfigApi = inject(VerificationDataConfigApi);

  protected readonly documentTypeFields = linkedSignal(() =>
    this.editDocumentTypeSignal().expectedFields.filter((field) => field.id),
  );

  loaderState = inject(LoaderState);

  // Processing is veritas-processor's: its profiles say how a document is processed, and the data
  // processor this type is linked to holds the fields expected in its documents, with their
  // definition. The expected fields here say what the extracted values are matched against.
  private readonly documentTypeApi = inject(DocumentTypeApi);
  protected readonly processingProfiles = signal<ProcessingProfile[]>([]);
  /** The profiles could not be read: the profile is typed in as a code instead of picked. */
  protected readonly processingProfilesUnavailable = signal(false);
  protected readonly dataProcessor = signal<DataProcessor | null>(null);
  protected readonly dataProcessorUnavailable = signal(false);
  private dataProcessorLoadedFor = '';

  /** The data processors a document type can be linked to. */
  protected readonly dataProcessors = signal<DataProcessor[]>([]);
  /** The data processors could not be read: the link is shown as it is and cannot be changed. */
  protected readonly dataProcessorsUnavailable = signal(false);

  /** The linked data processor's id when the list does not hold it (it was removed). */
  protected readonly unknownDataProcessor = computed(() => {
    const id = (this.editDocumentTypeSignal().dataProcessorId ?? '').trim();
    return id && !this.dataProcessors().some((processor) => (processor.id ?? '').toLowerCase() === id.toLowerCase())
      ? id
      : '';
  });

  /** The chosen profile when the list does not hold it (removed, or typed in earlier). */
  protected readonly unknownProcessingProfile = computed(() => {
    const code = (this.editDocumentTypeSignal().processingProfileCode ?? '').trim();
    return code && !this.processingProfiles().some((profile) => profile.code === code) ? code : '';
  });

  /** Fields of the data processor that have no expected field (no matching rule) here. */
  protected readonly unmatchedProcessorFields = computed<DataProcessorField[]>(() => {
    const expected = new Set(
      this.editDocumentTypeSignal().expectedFields.map((field) => (field.field ?? '').trim().toLowerCase()),
    );
    return (this.dataProcessor()?.expectedFields ?? []).filter(
      (field) => !expected.has((field.field ?? '').trim().toLowerCase()),
    );
  });

  constructor() {
    this.documentTypeApi.dataProcessors().subscribe({
      next: (processors) => this.dataProcessors.set(processors ?? []),
      error: () => this.dataProcessorsUnavailable.set(true),
    });

    this.documentTypeApi.processingProfiles().subscribe({
      next: (profiles) => this.processingProfiles.set(profiles ?? []),
      error: () => this.processingProfilesUnavailable.set(true),
    });

    effect(() => {
      // Reloaded after every save: saving expected fields changes the data processor
      const documentType = this.documentTypeApiStore.data();
      const id = this.editDocumentTypeSignal().id;
      const key = `${id}:${documentType?.modifiedAt ?? ''}:${this.editDocumentTypeSignal().expectedFields.length}`;
      if (!id || key === this.dataProcessorLoadedFor) {
        return;
      }
      this.dataProcessorLoadedFor = key;
      this.documentTypeApi.dataProcessor(id).subscribe({
        next: (processor) => {
          this.dataProcessor.set(processor ?? null);
          this.dataProcessorUnavailable.set(false);
        },
        error: () => this.dataProcessorUnavailable.set(true),
      });
    });

    effect(() => {
      this.loaderState.isLoading.set(this.loading());
    });

    effect(() => {
      let docType = this.documentTypeApiStore.data();

      if (docType) {
        this.editDocumentTypeSignal.set(this.updateDocumentTypeSignal(docType));
      }
    });

    effect(() => {
      const error = this.error();

      if (error) {
        toast.error(this.messages()[0] || 'An error occurred while saving the document type.');
      }
    });

    effect(() => {
      const success = this.success();

      if (success) {
        toast.success(this.messages()[0] || 'Document type saved successfully.');
      }
    });
  }

  ngOnInit(): void {
    this.documentTypeApiStore.reset();

    if (this.id && this.id !== '') {
      this.loaderState.message.set('Loading document type');
      this.documentTypeApiStore.findById({ id: this.id });
    }
  }

  ngAfterViewInit(): void {}

  ngOnDestroy(): void {}

  discardChanges(): void {
    const current = this.documentTypeApiStore.data();

    if (current?.id) {
      this.editDocumentTypeSignal.set(this.updateDocumentTypeSignal(current));
      return;
    }

    this.editDocumentTypeSignal.set(new EditDocumentTypeVarsForm());
  }

  updateField<K extends keyof EditDocumentTypeVarsForm>(
    field: K,
    value: EditDocumentTypeVarsForm[K],
  ): void {
    this.editDocumentTypeSignal.update((state) => ({
      ...state,
      [field]: value,
    }));
  }

  createNewExpectedFields(): ExpectedFieldDTO {
    let field = new ExpectedFieldDTO();
    field.documentTypeId = this.editDocumentTypeSignal().id;
    field.documentType = this.editDocumentTypeSignal().name;
    return field;
  }

  /** Opens the expected field dialog for a field the data processor already has, to give it a matching rule here. */
  expectedFieldsAddFromProcessor(processorField: DataProcessorField): void {
    const field = this.createNewExpectedFields();
    field.field = processorField.field;
    field.fieldLabel = processorField.fieldLabel;
    field.fieldType = processorField.fieldType;
    field.format = processorField.format;
    field.many = processorField.many;
    field.mandatory = processorField.mandatory;
    field.matchTo = processorField.matchTo;
    field.targetType = processorField.targetType ?? field.targetType;
    field.exactMatch = processorField.exactMatch;
    this.expectedFieldsAdd(field);
  }

  expectedFieldsAdd(preset?: ExpectedFieldDTO) {
    const dialogRef = this.dialog.open(ExpectedFieldDialogComponent, {
      width: '760px',
      maxWidth: '95vw',
      data: {
        title: 'Add Expected Field',
        field: preset ?? this.createNewExpectedFields(),
      },
    });

    dialogRef.afterClosed().subscribe((result?: ExpectedFieldDTO) => {
      if (!result) {
        return;
      }

      this.editDocumentTypeSignal.update((value) => ({
        ...value,
        expectedFields: [result, ...value.expectedFields],
      }));

      this.expectedFieldIndex.set(0);

      this.saveDocumentType();
    });
  }

  expectedFieldsEdit(index: number, selected: ExpectedFieldDTO): void {
    const dialogRef = this.dialog.open(ExpectedFieldDialogComponent, {
      width: '760px',
      maxWidth: '95vw',
      data: {
        title: 'Edit Expected Field',
        field: {
          ...selected,
        },
      },
    });

    dialogRef.afterClosed().subscribe((result?: ExpectedFieldDTO) => {
      if (!result) {
        return;
      }

      this.editDocumentTypeSignal.update((value) => ({
        ...value,
        expectedFields: value.expectedFields.map((item, itemIndex) =>
          itemIndex === index ? result : item,
        ),
      }));
      this.saveDocumentType();
    });
  }

  expectedFieldsRemove(i: number, selected: ExpectedFieldDTO) {
    swalFire({
      title: 'Are you sure?',
      text: `This will remove the field "${selected.field}" from the expected fields list.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, remove it!',
    }).then((result) => {
      if (result.isConfirmed) {
        this.editDocumentTypeSignal.update((value) => {
          const expectedFields = value.expectedFields.filter(
            (_: any, index: number) => index !== i,
          );
          const nextIndex = Math.max(
            0,
            Math.min(this.expectedFieldIndex(), expectedFields.length - 1),
          );
          this.expectedFieldIndex.set(nextIndex);

          return {
            ...value,
            expectedFields: expectedFields,
          };
        });
      }
    });
  }

  expectedFieldCount(): number {
    return this.editDocumentTypeSignal().expectedFields.length;
  }

  currentExpectedFieldIndex(): number {
    const count = this.expectedFieldCount();

    if (count === 0) {
      return 0;
    }

    return Math.max(0, Math.min(this.expectedFieldIndex(), count - 1));
  }

  canGoToPreviousExpectedField(): boolean {
    return this.currentExpectedFieldIndex() > 0;
  }

  canGoToNextExpectedField(): boolean {
    return this.currentExpectedFieldIndex() < this.expectedFieldCount() - 1;
  }

  goToPreviousExpectedField(): void {
    if (!this.canGoToPreviousExpectedField()) {
      return;
    }

    this.expectedFieldIndex.update((index) => Math.max(0, index - 1));
  }

  goToNextExpectedField(): void {
    if (!this.canGoToNextExpectedField()) {
      return;
    }

    this.expectedFieldIndex.update((index) => Math.min(this.expectedFieldCount() - 1, index + 1));
  }

  createNewVerificationDataConfig(): VerificationDataConfigDTO {
    const config = new VerificationDataConfigDTO();
    config.documentTypeId = this.editDocumentTypeSignal().id;
    config.documentType = this.editDocumentTypeSignal().name;
    config.name = '';
    return config;
  }

  verificationDataConfigsAdd(): void {
    this.editDocumentTypeSignal.update((value) => ({
      ...value,
      verificationDataConfigs: [
        this.createNewVerificationDataConfig(),
        ...value.verificationDataConfigs,
      ],
    }));

    this.verificationDataConfigIndex.set(0);
  }

  verificationDataConfigsRemove(i: number, selected: VerificationDataConfigDTO): void {
    swalFire({
      title: 'Are you sure?',
      text: `This will remove the verification data config "${selected.name || 'Untitled'}".`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, remove it!',
    }).then((result) => {
      if (result.isConfirmed) {
        this.editDocumentTypeSignal.update((value) => {
          const verificationDataConfigs = value.verificationDataConfigs.filter(
            (_: any, index: number) => index !== i,
          );

          const nextIndex = Math.max(
            0,
            Math.min(this.verificationDataConfigIndex(), verificationDataConfigs.length - 1),
          );
          this.verificationDataConfigIndex.set(nextIndex);

          return {
            ...value,
            verificationDataConfigs,
          };
        });

        this.loading.set(true);
        this.loaderState.message.set('Removing verification data config');
        this.verificationConfigApi.remove(selected.id).subscribe({
          next: (done: boolean) => {
            if (done) {
              this.saveDocumentType();
              toast.success('Verification data config removed successfully.');
            }

            this.loading.set(false);
          },
          error: (error: any) => {
            toast.error('Failed to remove verification data config.');
            this.loading.set(false);
          },
        });
      }
    });
  }

  // updateVerificationDataConfig(index: number, field: keyof VerificationDataConfigDTO, value: any): void {
  //   this.editDocumentTypeSignal.update((state) => ({
  //     ...state,
  //     verificationDataConfigs: state.verificationDataConfigs.map((item, itemIndex) => {
  //       if (itemIndex !== index) {
  //         return item;
  //       }

  //       return {
  //         ...item,
  //         [field]: value,
  //       };
  //     }),
  //   }));
  // }

  isVerificationDataConfigKeySelected(configIndex: number, field: ExpectedFieldDTO): boolean {
    let fields =
      this.editDocumentTypeSignal().verificationDataConfigs[configIndex]?.expectedFields || [];

    let fieldIds = fields.map((f: any) => f.id);

    return fieldIds.includes(field.id) ?? false;

    // return this.editDocumentTypeSignal().verificationDataConfigs[configIndex]?.expectedFields?.includes(field) ?? false;
  }

  verificationDataConfigCount(): number {
    return this.editDocumentTypeSignal().verificationDataConfigs.length;
  }

  currentVerificationDataConfigIndex(): number {
    const count = this.verificationDataConfigCount();

    if (count === 0) {
      return 0;
    }

    return Math.max(0, Math.min(this.verificationDataConfigIndex(), count - 1));
  }

  canGoToPreviousVerificationDataConfig(): boolean {
    return this.currentVerificationDataConfigIndex() > 0;
  }

  canGoToNextVerificationDataConfig(): boolean {
    return this.currentVerificationDataConfigIndex() < this.verificationDataConfigCount() - 1;
  }

  goToPreviousVerificationDataConfig(): void {
    if (!this.canGoToPreviousVerificationDataConfig()) {
      return;
    }

    this.verificationDataConfigIndex.update((index) => Math.max(0, index - 1));
  }

  goToNextVerificationDataConfig(): void {
    if (!this.canGoToNextVerificationDataConfig()) {
      return;
    }

    this.verificationDataConfigIndex.update((index) =>
      Math.min(this.verificationDataConfigCount() - 1, index + 1),
    );
  }

  toggleVerificationDataConfigKey(
    configIndex: number,
    field: ExpectedFieldDTO,
    checked: boolean,
  ): void {
    this.editDocumentTypeSignal.update((state) => ({
      ...state,
      verificationDataConfigs: state.verificationDataConfigs.map((config, index) => {
        if (index !== configIndex) {
          return config;
        }

        const selectedKeyFields = Array.isArray(config.expectedFields) ? config.expectedFields : [];
        const keyFields = checked
          ? selectedKeyFields.includes(field)
            ? selectedKeyFields
            : [...selectedKeyFields, field]
          : selectedKeyFields.filter((item: ExpectedFieldDTO) => item.id !== field.id);

        return {
          ...config,
          expectedFields: keyFields,
        };
      }),
    }));
  }

  // isVerificationTagSelected(tag: VerificationTag): boolean {
  //   return this.editDocumentTypeSignal().verificationTags.includes(tag);
  // }

  // toggleVerificationTag(tag: VerificationTag, checked: boolean): void {
  //   this.editDocumentTypeSignal.update((state) => {
  //     const verificationTags = checked
  //       ? state.verificationTags.includes(tag)
  //         ? state.verificationTags
  //         : [...state.verificationTags, tag]
  //       : state.verificationTags.filter((item) => item !== tag);

  //     return {
  //       ...state,
  //       verificationTags,
  //     };
  //   });
  // }

  updateDocumentTypeSignal(documentType: DocumentTypeDTO): EditDocumentTypeVarsForm {
    return {
      code: documentType.code ?? '',
      createdAt: documentType.createdAt,
      createdBy: documentType.createdBy,
      description: documentType.description,
      processingProfileCode: documentType.processingProfileCode ?? '',
      dataProcessorId: documentType.dataProcessorId ?? '',
      expires: documentType.expires,
      expiryField: documentType.expiryField,
      expiresIn: documentType.expiresIn,
      expiryPeriod: documentType.expiryPeriod,
      id: documentType.id,
      modifiedAt: documentType.modifiedAt,
      modifiedBy: documentType.modifiedBy,
      name: documentType.name ?? '',
      expectedFields: documentType.expectedFields || [],
      verificationDataConfigs: (documentType.verificationDataConfigs || []).map((config: VerificationDataConfigDTO) => ({
        ...config,
        name: config.name ?? '',
      })),
    };
  }

  saveDocumentType(): void {
    let formData: EditDocumentTypeVarsForm = this.editDocumentTypeSignal();
    let docType = new DocumentTypeDTO();
    docType.code = formData.code || null;
    docType.createdAt = formData.createdAt;
    docType.createdBy = formData.createdBy;
    docType.description = formData.description;
    docType.processingProfileCode = formData.processingProfileCode?.trim() || null;
    docType.dataProcessorId = formData.dataProcessorId?.trim() || null;
    docType.expires = formData.expires;
    docType.expiryField = formData.expiryField;
    docType.expiryPeriod = formData.expiryPeriod;
    docType.expiresIn = formData.expiresIn;
    docType.id = formData.id;
    docType.modifiedAt = formData.modifiedAt;
    docType.modifiedBy = formData.modifiedBy;
    docType.name = formData.name || null;
    docType.expectedFields = formData.expectedFields || [];
    docType.verificationDataConfigs = (formData.verificationDataConfigs || []).map((config) => ({
      ...config,
      name: config.name || null,
    }));

    this.loaderState.message.set('Saving document type');
    this.documentTypeApiStore.save({
      documentType: docType,
    });
  }

  expiryFieldCompare(o1: ExpectedFieldDTO | null | undefined, o2: ExpectedFieldDTO | null | undefined): boolean {
    return o1 && o2 ? o1.id === o2.id : o1 === o2;
  }

  trackByIndex(index: number): number {
    return index;
  }
}

interface ExpectedFieldDialogData {
  title?: string;
  field: ExpectedFieldDTO;
}

const MATCH_TO_EXCLUDED_FIELDS = new Set([
  'id',
  'createdBy',
  'createdAt',
  'modifiedBy',
  'modifiedAt',
]);

const EXCLUDED_TARGET_TYPES = new Set<TargetEntity>([
  TargetEntity.BRANCH,
  TargetEntity.SUBSCRIPTION,
  TargetEntity.CLIENT_REQUEST,
  TargetEntity.DOCUMENT,
  TargetEntity.SETTINGS,
]);

const getDtoMatchToFields = (dto: object): string[] =>
  Object.keys(dto).filter((field) => !MATCH_TO_EXCLUDED_FIELDS.has(field));

const TARGET_ENTITY_MATCH_TO_FACTORIES: Partial<Record<TargetEntity, () => string[]>> = {
  [TargetEntity.INDIVIDUAL]: () => getDtoMatchToFields(new IndividualDTO()),
  [TargetEntity.ORGANISATION]: () => getDtoMatchToFields(new OrganisationDTO()),
  [TargetEntity.INVOICE]: () => getDtoMatchToFields(new KycInvoiceDTO()),
  [TargetEntity.KYC_RECORD]: () => getDtoMatchToFields(new KycRecordDTO()),
  [TargetEntity.CONTACT]: () => getDtoMatchToFields(new ContactDTO()),
  [TargetEntity.SETTINGS]: () => getDtoMatchToFields(new SettingsDTO()),
};

@Component({
  selector: 'app-expected-field-dialog',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    FormField,
    FormRoot,
    TranslateModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 mat-dialog-title>{{ data.title || 'Expected Field' }}</h2>

    <form mat-dialog-content id="expected-field-form" [formRoot]="expectedFieldForm">
      <div class="dialog-form-grid">
        <mat-form-field appearance="outline">
          <mat-label>Field Name</mat-label>
          <input matInput [formField]="expectedFieldForm.field" placeholder="e.g. documentNumber" />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Field Label</mat-label>
          <input
            matInput
            [formField]="expectedFieldForm.fieldLabel"
            placeholder="e.g. Document Number"
          />
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Field Type</mat-label>
          <mat-select [formField]="expectedFieldForm.fieldType">
            @for (option of fieldTypeOptions; track option) {
              <mat-option [value]="option">
                <span translate>expected.field.type.{{ option }}</span>
              </mat-option>
            }
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Target Type</mat-label>
          <mat-select [formField]="expectedFieldForm.targetType">
            @for (option of targetTypeOptions; track option) {
              <mat-option [value]="option">
                <span translate>target.entity.{{ option }}</span>
              </mat-option>
            }
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Match To</mat-label>
          <mat-select [formField]="expectedFieldForm.matchTo">
            @if (matchToOptions().length === 0) {
              <mat-option [value]="null" disabled>Select target type first</mat-option>
            } @else {
              @for (option of matchToOptions(); track option) {
                <mat-option [value]="option">{{ option }}</mat-option>
              }
            }
          </mat-select>
        </mat-form-field>

        @if(expectedFieldSignal().matchTo) { 
        <mat-checkbox [formField]="expectedFieldForm.exactMatch">Exact Match</mat-checkbox>
        }
        <mat-form-field appearance="outline" class="format-field">
          <mat-label>Format</mat-label>
          <textarea
            matInput
            [formField]="expectedFieldForm.format"
            placeholder="e.g. dd/MM/yyyy"
          ></textarea>
        </mat-form-field>

        <div class="checkbox-row">
          <mat-checkbox [formField]="expectedFieldForm.mandatory">Mandatory</mat-checkbox>
          <mat-checkbox [formField]="expectedFieldForm.many">Many</mat-checkbox>
        </div>
      </div>
    </form>

    <mat-dialog-actions align="end">
      <button mat-stroked-button type="button" (click)="onCancel()">Cancel</button>
      <button
        mat-flat-button
        color="primary"
        type="submit" form="expected-field-form"
        [disabled]="!expectedFieldForm().valid()"
      >
        Save
      </button>
    </mat-dialog-actions>
  `,
  styles: [
    `
      .mat-mdc-dialog-content {
        min-width: 680px;
      }

      .dialog-form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
        padding-top: 8px;
      }

      mat-form-field {
        width: 100%;
      }

      .format-field {
        grid-column: 1 / -1;
      }

      .format-field textarea {
        min-height: 88px;
        resize: vertical;
      }

      .checkbox-row {
        grid-column: 1 / -1;
        display: flex;
        gap: 18px;
        padding: 4px 2px;
      }

      @media (max-width: 760px) {
        .mat-mdc-dialog-content {
          min-width: 100%;
        }

        .dialog-form-grid {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
})
export class ExpectedFieldDialogComponent {
  private dialogRef = inject(MatDialogRef<ExpectedFieldDialogComponent>);
  data: ExpectedFieldDialogData = inject(MAT_DIALOG_DATA);

  protected readonly fieldTypeOptions = Object.values(ExpectedFieldType);
  protected readonly targetTypeOptions = Object.values(TargetEntity).filter(
    (targetType) => !EXCLUDED_TARGET_TYPES.has(targetType),
  );
  protected readonly matchToOptions = computed(() => {
    const targetType = this.expectedFieldSignal().targetType as TargetEntity | null | undefined;

    if (!targetType) {
      return [];
    }

    return TARGET_ENTITY_MATCH_TO_FACTORIES[targetType]?.() ?? [];
  });

  expectedFieldSignal = signal<ExpectedFieldDTO>(this.data.field);
  expectedFieldForm = form(this.expectedFieldSignal, (path) => {
    required(path.field);
  }, { submission: { action: async () => this.onSave() } });

  constructor() {
    effect(() => {
      const matchTo = this.expectedFieldSignal().matchTo;
      const options = this.matchToOptions();

      if (!matchTo || options.includes(matchTo)) {
        return;
      }

      this.expectedFieldSignal.update((field) => ({
        ...field,
        matchTo: null,
      }));
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (!this.expectedFieldForm().valid()) {
      return;
    }

    this.dialogRef.close(this.expectedFieldSignal());
  }
}
