package bw.co.roguesystems.ai.processor.verification;

import bw.co.roguesystems.ai.processor.DataProcessorMapper;
import bw.co.roguesystems.ai.processor.field.ExpectedFieldMapper;
import bw.co.roguesystems.ai.utils.MappingUtils;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfig;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigDTO;

import java.util.Collection;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(
    componentModel = "spring",
    uses = {
        MappingUtils.class,
        DataProcessorMapper.class,
        ExpectedFieldMapper.class
    }
)
public abstract class VerificationDataConfigMapper {    
    
    /**
     * Converts this entity to an object of type {@link VerificationDataConfigDTO}.
     * @param entity
     * @return VerificationDataConfigDTO
     */
    // WARNING! No conversion for target.dataProcessor (can't convert source.getDataProcessor():bw.co.roguesystems.ai.processor.DataProcessor to java.lang.String)
    @Mapping(target = "dataProcessor", source = "dataProcessor.name")
    @Mapping(source = "dataProcessor.id", target = "dataProcessorId")
    public abstract VerificationDataConfigDTO toVerificationDataConfigDTO(VerificationDataConfig entity);

     /**
     * Converts this DAO's entity to a Collection of instances of type {@link VerificationDataConfigDTO}.
     * @param entities
     * @return Collection<VerificationDataConfigDTO>     */
    public abstract List<VerificationDataConfigDTO> toVerificationDataConfigDTOCollection(Collection<VerificationDataConfig> entities);

    /**
     * Converts an instance of type {@link VerificationDataConfigDTO} to this DAO's entity.
     * @param verificationDataConfigDTO
     * @return VerificationDataConfig
     */
    @InheritInverseConfiguration
    public abstract VerificationDataConfig verificationDataConfigDTOToEntity(VerificationDataConfigDTO verificationDataConfigDTO);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @InheritInverseConfiguration
    public abstract void updateVerificationDataConfigFromVerificationDataConfigDTO(VerificationDataConfigDTO verificationDataConfigDTO, @MappingTarget VerificationDataConfig entity);

}