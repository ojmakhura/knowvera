package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.TargetEntity;
import jakarta.validation.Valid;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;

/**
 * <p>
 * Spring Service base class for <code>DataFieldGroupService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see DataFieldGroupService
 */
@CacheConfig(cacheNames = "dataFieldGroups")
public abstract class DataFieldGroupServiceBase
    implements DataFieldGroupService
{
    protected Logger logger = LoggerFactory.getLogger(DataFieldGroupService.class);
    protected final DataFieldGroupRepository dataFieldGroupRepository;
    protected final DataFieldGroupMapper dataFieldGroupMapper;

    public DataFieldGroupServiceBase(
        DataFieldGroupRepository dataFieldGroupRepository,
        DataFieldGroupMapper dataFieldGroupMapper    ) {
        this.dataFieldGroupRepository = dataFieldGroupRepository;
        this.dataFieldGroupMapper = dataFieldGroupMapper;
    }

    /**
     * Gets the reference to <code>dataFieldGroup</code>'s repository.
     * @return dataFieldGroupRepository
     */
    public DataFieldGroupRepository getDataFieldGroupRepository() {
        return dataFieldGroupRepository;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Cacheable(key = "#id")
    public DataFieldGroupDTO findById(final String id)
    {
        if (id == null || id.trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findById(String id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleFindById(id);
        }
        catch (Throwable th)
        {
            throw new DataFieldGroupServiceException(
                "Error performing 'DataFieldGroupService.findById(String id)' --> " + th,
                th);
        }
    }

    /**
     * Performs the core logic for {@link #findById(String)}
     * @param id java.lang.String TODO: Model Documentation for DataFieldGroupService.findById(id)
     * @return DataFieldGroupDTO
     * @throws Exception
     */
    protected abstract DataFieldGroupDTO handleFindById(String id)
        throws Exception;

    /**
     * {@inheritDoc}
     */
    @Override
    @Caching(evict = { @CacheEvict(cacheNames = {"dataFieldGroups"}, allEntries = true, beforeInvocation = true) }, put = { @CachePut(key = "#result.id", unless = "#result == null") })
    public DataFieldGroupDTO save(final @Valid DataFieldGroupDTO fieldGroup)
    {
        if (fieldGroup == null)
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save(@Valid DataFieldGroupDTO fieldGroup) - 'fieldGroup' can not be null");
        }
        if (fieldGroup.getLabel() == null || fieldGroup.getLabel().trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save(@Valid DataFieldGroupDTO fieldGroup) - 'fieldGroup.label' can not be null or empty");
        }
        if (fieldGroup.getDescription() == null || fieldGroup.getDescription().trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save(@Valid DataFieldGroupDTO fieldGroup) - 'fieldGroup.description' can not be null or empty");
        }
        if (fieldGroup.getTargetType() == null)
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save(@Valid DataFieldGroupDTO fieldGroup) - 'fieldGroup.targetType' can not be null");
        }
        try
        {
            return this.handleSave(fieldGroup);
        }
        catch (Throwable th)
        {
            throw new DataFieldGroupServiceException(
                "Error performing 'DataFieldGroupService.save(@Valid DataFieldGroupDTO fieldGroup)' --> " + th,
                th);
        }
    }

    /**
     * Performs the core logic for {@link #save(@Valid DataFieldGroupDTO)}
     * @param fieldGroup DataFieldGroupDTO TODO: Model Documentation for DataFieldGroupService.save(fieldGroup)
     * @return DataFieldGroupDTO
     * @throws Exception
     */
    protected abstract DataFieldGroupDTO handleSave(@Valid DataFieldGroupDTO fieldGroup)
        throws Exception;

    /**
     * {@inheritDoc}
     */
    @Override
    @CacheEvict(cacheNames = {"dataFieldGroups"}, allEntries = true)
    public boolean remove(final String id)
    {
        if (id == null || id.trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.remove(String id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleRemove(id);
        }
        catch (Throwable th)
        {
            throw new DataFieldGroupServiceException(
                "Error performing 'DataFieldGroupService.remove(String id)' --> " + th,
                th);
        }
    }

    /**
     * Performs the core logic for {@link #remove(String)}
     * @param id java.lang.String TODO: Model Documentation for DataFieldGroupService.remove(id)
     * @return boolean
     * @throws Exception
     */
    protected abstract boolean handleRemove(String id)
        throws Exception;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<DataFieldGroupDTO> findByTarget(final TargetEntity targetType)
    {
        if (targetType == null)
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findByTarget(TargetEntity targetType) - 'targetType' can not be null");
        }
        try
        {
            return this.handleFindByTarget(targetType);
        }
        catch (Throwable th)
        {
            throw new DataFieldGroupServiceException(
                "Error performing 'DataFieldGroupService.findByTarget(TargetEntity targetType)' --> " + th,
                th);
        }
    }

    /**
     * Performs the core logic for {@link #findByTarget(TargetEntity)}
     * @param targetType TargetEntity TODO: Model Documentation for
DataFieldGroupService.findByTarget(targetType)
     * @return List<DataFieldGroupDTO>
     * @throws Exception
     */
    protected abstract List<DataFieldGroupDTO> handleFindByTarget(TargetEntity targetType)
        throws Exception;

    /**
     * {@inheritDoc}
     */
    @Override
    @CacheEvict(cacheNames = {"dataFieldGroups"}, allEntries = true)
    public DataFieldGroupDTO removeField(final String id, final String fieldId)
    {
        if (id == null || id.trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.removeField(String id, String fieldId) - 'id' can not be null or empty");
        }
        if (fieldId == null || fieldId.trim().isEmpty())
        {
            throw new IllegalArgumentException(
                "bw.co.roguesystems.ai.processor.data.DataFieldGroupService.removeField(String id, String fieldId) - 'fieldId' can not be null or empty");
        }
        try
        {
            return this.handleRemoveField(id, fieldId);
        }
        catch (Throwable th)
        {
            throw new DataFieldGroupServiceException(
                "Error performing 'DataFieldGroupService.removeField(String id, String fieldId)' --> " + th,
                th);
        }
    }

    /**
     * Performs the core logic for {@link #removeField(String, String)}
     * @param id java.lang.String TODO: Model Documentation for DataFieldGroupService.removeField(id)
     * @param fieldId java.lang.String TODO: Model Documentation for DataFieldGroupService.removeField(fieldId)
     * @return DataFieldGroupDTO
     * @throws Exception
     */
    protected abstract DataFieldGroupDTO handleRemoveField(String id, String fieldId)
        throws Exception;

    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    /**protected java.security.Principal getPrincipal()
    {
        return bw.co.roguesystems.ai.PrincipalStore.get();
    }*/


}