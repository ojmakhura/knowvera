package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.TargetEntity;
import jakarta.validation.Valid;
import java.util.List;

/**
 * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService
 */
public interface DataFieldGroupService
{
    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findById
     * @param id TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findById(id)
     * @return DataFieldGroupDTO
     */
    public DataFieldGroupDTO findById(String id) ;

    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save
     * @param fieldGroup TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.save(fieldGroup)
     * @return DataFieldGroupDTO
     */
    public DataFieldGroupDTO save(@Valid DataFieldGroupDTO fieldGroup) ;

    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.remove
     * @param id TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.remove(id)
     * @return boolean
     */
    public boolean remove(String id) ;

    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findByTarget
     * @param targetType TODO: Model Documentation for
bw.co.roguesystems.ai.processor.data.DataFieldGroupService.findByTarget(targetType)
     * @return List<DataFieldGroupDTO>
     */
    public List<DataFieldGroupDTO> findByTarget(TargetEntity targetType) ;

    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.removeField
     * @param id TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.removeField(id)
     * @param fieldId TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupService.removeField(fieldId)
     * @return DataFieldGroupDTO
     */
    public DataFieldGroupDTO removeField(String id, String fieldId) ;

}