package bw.co.roguesystems.ai.processor.data;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.BeanMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

import bw.co.roguesystems.ai.processor.field.ExpectedFieldMapper;
import bw.co.roguesystems.ai.utils.MappingUtils;
import bw.co.roguesystems.ai.processor.data.DataFieldGroup;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupDTO;

@Mapper(
    componentModel = "spring"
    , uses = {
        DataFieldMapper.class,
        ExpectedFieldMapper.class,
        DataFieldGroupMapper.class,
        MappingUtils.class
    }
)
public abstract class DataFieldGroupMapper {
    
    /**
     * Converts this entity to an object of type {@link DataFieldGroupDTO}.
     * @param entity
     * @return DataFieldGroupDTO
     */
    @Mapping(source = "dataFields", target = "groupFields")
    public abstract DataFieldGroupDTO toDataFieldGroupDTO(DataFieldGroup entity);

     /**
     * Converts this DAO's entity to a Collection of instances of type {@link DataFieldGroupDTO}.
     * @param entities
     * @return Collection<DataFieldGroupDTO>     */
    public abstract List<DataFieldGroupDTO> toDataFieldGroupDTOCollection(Collection<DataFieldGroup> entities);

    /**
     * Converts an instance of type {@link DataFieldGroupDTO} to this DAO's entity.
     * @param dataFieldGroupDTO
     * @return DataFieldGroup
     */
    @InheritInverseConfiguration
    public abstract DataFieldGroup dataFieldGroupDTOToEntity(DataFieldGroupDTO dataFieldGroupDTO);


    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @InheritInverseConfiguration
    public abstract void updateDataFieldGroupFromDataFieldGroupDTO(DataFieldGroupDTO dataFieldGroupDTO, @MappingTarget DataFieldGroup entity);

}