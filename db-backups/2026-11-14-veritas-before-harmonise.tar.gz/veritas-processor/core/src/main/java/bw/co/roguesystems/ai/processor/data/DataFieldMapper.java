package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.processor.field.ExpectedFieldMapper;
import bw.co.roguesystems.ai.utils.MappingUtils;
import bw.co.roguesystems.ai.processor.data.DataField;
import bw.co.roguesystems.ai.processor.data.DataFieldDTO;

import java.util.Collection;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", uses = {
        ExpectedFieldMapper.class,
        DataFieldGroupMapper.class,
        MappingUtils.class
})
public abstract class DataFieldMapper {

    /**
     * Converts this entity to an object of type {@link DataFieldDTO}.
     * 
     * @param entity
     * @return DataFieldDTO
     */
    @Mapping(target = "fieldId", source = "expectedField.id")
    @Mapping(target = "field", source = "expectedField.field")
    @Mapping(target = "fieldGroupId", source = "dataFieldGroup.id")
    public abstract DataFieldDTO toDataFieldDTO(DataField entity);

    /**
     * Converts this DAO's entity to a Collection of instances of type
     * {@link DataFieldDTO}.
     * 
     * @param entities
     * @return Collection<DataFieldDTO>
     */
    public abstract List<DataFieldDTO> toDataFieldDTOCollection(Collection<DataField> entities);

    /**
     * Converts an instance of type {@link DataFieldDTO} to this DAO's entity.
     * 
     * @param dataFieldDTO
     * @return DataField
     */
    @InheritInverseConfiguration
    public abstract DataField dataFieldDTOToEntity(DataFieldDTO dataFieldDTO);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @InheritInverseConfiguration
    public abstract void updateDataFieldFromDataFieldDTO(DataFieldDTO dataFieldDTO,
            @MappingTarget DataField entity);

}