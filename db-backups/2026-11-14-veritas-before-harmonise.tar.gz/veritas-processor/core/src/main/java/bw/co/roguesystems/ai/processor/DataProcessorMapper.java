package bw.co.roguesystems.ai.processor;

import bw.co.roguesystems.ai.processor.field.ExpectedFieldMapper;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfig;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigDTO;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigMapper;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigRepository;
import bw.co.roguesystems.ai.utils.MappingUtils;
import bw.co.roguesystems.ai.processor.DataProcessor;
import bw.co.roguesystems.ai.processor.DataProcessorDTO;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.mapstruct.BeanMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(
    componentModel = "spring",
    uses = {
        MappingUtils.class,
        VerificationDataConfigMapper.class,
        ExpectedFieldMapper.class
    }
)
public abstract class DataProcessorMapper {
    
    @Autowired
    protected VerificationDataConfigRepository verificationDataConfigRepository;

    @Autowired
    private VerificationDataConfigMapper verificationDataConfigMapper;
    
    /**
     * Converts this entity to an object of type {@link DataProcessorDTO}.
     * @param entity
     * @return DataProcessorDTO
     */
    @Mapping(target = "expectedFields", source = "expectedFields")
    @Mapping(target = "verificationDataConfigs", source = "verificationDataConfigs")
    public abstract DataProcessorDTO toDataProcessorDTO(DataProcessor entity);

    protected Collection<VerificationDataConfigDTO> mapVerificationDataConfigs(Collection<VerificationDataConfig> verificationDataConfigs) {

        Collection<UUID> ids = verificationDataConfigs.stream()
            .filter(config -> config.getId() != null)
            .map(VerificationDataConfig::getId)
            .toList();

        Collection<VerificationDataConfig> configs = verificationDataConfigRepository.findAllById(ids);
        return configs.stream()
            .map(verificationDataConfigMapper::toVerificationDataConfigDTO)
            .toList();
    }

     /**
     * Converts this DAO's entity to a Collection of instances of type {@link DataProcessorDTO}.
     * @param entities
     * @return Collection<DataProcessorDTO>     */
    public abstract List<DataProcessorDTO> toDataProcessorDTOCollection(Collection<DataProcessor> entities);

    /**
     * Converts an instance of type {@link DataProcessorDTO} to this DAO's entity.
     * @param dataProcessorDTO
     * @return DataProcessor
     */
    @InheritInverseConfiguration
    public abstract DataProcessor dataProcessorDTOToEntity(DataProcessorDTO dataProcessorDTO);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @InheritInverseConfiguration
    public abstract void updateDataProcessorFromDataProcessorDTO(DataProcessorDTO dataProcessorDTO, @MappingTarget DataProcessor entity);

}