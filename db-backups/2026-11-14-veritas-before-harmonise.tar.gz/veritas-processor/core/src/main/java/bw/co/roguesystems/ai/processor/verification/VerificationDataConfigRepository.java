package bw.co.roguesystems.ai.processor.verification;

import java.util.UUID;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

public interface VerificationDataConfigRepository extends JpaRepository<VerificationDataConfig, UUID>, JpaSpecificationExecutor<VerificationDataConfig> {

    @Query(
        value = """
            SELECT vdc
    FROM VerificationDataConfig vdc
    JOIN FETCH vdc.expectedFields
    WHERE vdc.dataProcessor.id = :dataProcessorId
        """
    )
    java.util.List<bw.co.roguesystems.ai.processor.verification.VerificationDataConfig> findByDataProcessorId(java.util.UUID dataProcessorId);

    @Query(
        value = """
            SELECT vdc
    FROM VerificationDataConfig vdc
    JOIN FETCH vdc.expectedFields
    WHERE vdc.dataProcessor.id = :dataProcessorId
        """
    )
    Page<VerificationDataConfig> findByDataProcessorId(java.util.UUID dataProcessorId, Pageable pageable);

    @Query(
        value = """
            SELECT COUNT(vdc.id)
                FROM VerificationDataConfig vdc
                WHERE vdc.dataProcessor.id = :dataProcessorId
        """
    )
    Optional<java.lang.Integer> countByDataProcessorId(java.util.UUID dataProcessorId);

}
