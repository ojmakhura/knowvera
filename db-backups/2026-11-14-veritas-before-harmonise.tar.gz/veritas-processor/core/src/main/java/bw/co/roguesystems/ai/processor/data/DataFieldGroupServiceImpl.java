package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.processor.data.DataField;
import bw.co.roguesystems.ai.processor.data.DataFieldRepository;
import bw.co.roguesystems.ai.processor.data.DataFieldGroup;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupDTO;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupRepository;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupServiceBase;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupServiceException;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import bw.co.roguesystems.ai.TargetEntity;

/**
 * @see bw.co.roguesystems.ai.processor.data.DataFieldGroupService
 */
@Service("dataFieldGroupService")
@Validated
public class DataFieldGroupServiceImpl
        extends DataFieldGroupServiceBase {

    private final DataFieldRepository dataFieldRepository;

    public DataFieldGroupServiceImpl(
            DataFieldGroupRepository dataFieldGroupRepository,
            DataFieldGroupMapper dataFieldGroupMapper,
            DataFieldRepository dataFieldRepository) {

        super(
                dataFieldGroupRepository,
                dataFieldGroupMapper);

        this.dataFieldRepository = dataFieldRepository;
    }

    /**
     * @see bw.co.roguesystems.ai.processor.data.DataFieldGroupService#findById(String)
     */
    @Override
    protected DataFieldGroupDTO handleFindById(String id)
            throws Exception {

        DataFieldGroup dataFieldGroup = this.dataFieldGroupRepository.findById(UUID.fromString(id))
                .orElseThrow(() -> new DataFieldGroupServiceException("DataFieldGroup not found for id: " + id));

        return this.dataFieldGroupMapper.toDataFieldGroupDTO(dataFieldGroup);
    }

    /**
     * @see bw.co.roguesystems.ai.processor.data.DataFieldGroupService#save(@Valid
     *      DataFieldGroupDTO)
     */
    @Override
    protected DataFieldGroupDTO handleSave(@Valid DataFieldGroupDTO fieldGroup)
            throws Exception {

        DataFieldGroup dataFieldGroup = dataFieldGroupMapper.dataFieldGroupDTOToEntity(fieldGroup);


        if (dataFieldGroup.getDataFields() != null) {

            for (DataField field : dataFieldGroup.getDataFields()) {
                field.setDataFieldGroup(dataFieldGroup);
            }

        }

        dataFieldGroup = this.dataFieldGroupRepository.save(dataFieldGroup);

        return this.dataFieldGroupMapper.toDataFieldGroupDTO(dataFieldGroup);
    }

    /**
     * @see bw.co.roguesystems.ai.processor.data.DataFieldGroupService#remove(String)
     */
    @Override
    protected boolean handleRemove(String id)
            throws Exception {

        if (!this.dataFieldGroupRepository.existsById(UUID.fromString(id))) {
            throw new DataFieldGroupServiceException(
                    "DataFieldGroup not found for id: " + id);
        }

        this.dataFieldGroupRepository.deleteById(UUID.fromString(id));
        return true;
    }

    @Override
    protected List<DataFieldGroupDTO> handleFindByTarget(TargetEntity targetType) throws Exception {

        Specification<DataFieldGroup> specification = (root, query, criteriaBuilder) -> criteriaBuilder
                .equal(root.get("targetType"), targetType);

        List<DataFieldGroup> dataFieldGroups = this.dataFieldGroupRepository.findAll(specification);

        return this.dataFieldGroupMapper.toDataFieldGroupDTOCollection(dataFieldGroups);
    }

    @Override
    protected DataFieldGroupDTO handleRemoveField(String id, String fieldId) throws Exception {

        dataFieldRepository.deleteById(UUID.fromString(fieldId));;

        DataFieldGroup dataFieldGroup = this.dataFieldGroupRepository.findById(UUID.fromString(id))
                .orElseThrow(() -> new DataFieldGroupServiceException(
                        "DataFieldGroup not found for id: " + id));

        return this.dataFieldGroupMapper.toDataFieldGroupDTO(dataFieldGroup);
    }
}