package bw.co.roguesystems.ai.processor.verification;

import bw.co.roguesystems.ai.processor.DataProcessor;
import bw.co.roguesystems.ai.processor.DataProcessorRepository;
import bw.co.roguesystems.ai.processor.field.ExpectedField;
import bw.co.roguesystems.ai.processor.field.ExpectedFieldRepository;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfig;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigDTO;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigRepository;
import bw.co.roguesystems.ai.processor.verification.VerificationDataConfigServiceBase;
import jakarta.validation.Valid;

import java.util.Collection;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

/**
 * @see bw.co.roguesystems.ai.processor.verification.VerificationDataConfigService
 */
@Service("verificationDataConfigService")
public class VerificationDataConfigServiceImpl
    extends VerificationDataConfigServiceBase
{
    private final DataProcessorRepository dataProcessorRepository;
    private final ExpectedFieldRepository expectedFieldRepository;
    private final JdbcTemplate jdbcTemplate;
    public VerificationDataConfigServiceImpl(
        VerificationDataConfigRepository verificationDataConfigRepository,
        VerificationDataConfigMapper verificationDataConfigMapper,
        DataProcessorRepository typeRepository,
        ExpectedFieldRepository expectedFieldRepository,
        JdbcTemplate jdbcTemplate
    ) {
        
        super(
            verificationDataConfigRepository,
            verificationDataConfigMapper
        );

        this.dataProcessorRepository = typeRepository;
        this.jdbcTemplate = jdbcTemplate;
        this.expectedFieldRepository = expectedFieldRepository;
    }

    /**
     * @see bw.co.roguesystems.ai.processor.verification.VerificationDataConfigService#findById(String)
     */
    @Override
    protected VerificationDataConfigDTO handleFindById(String id)
        throws Exception
    {
        VerificationDataConfig verificationDataConfig = this.verificationDataConfigRepository.findById(UUID.fromString(id))
            .orElseThrow(() -> new RuntimeException("VerificationDataConfig not found for id: " + id));

        return this.verificationDataConfigMapper.toVerificationDataConfigDTO(verificationDataConfig);
    }

    /**
     * @see bw.co.roguesystems.ai.processor.verification.VerificationDataConfigService#save(@Valid VerificationDataConfigDTO)
     */
    @Override
    protected VerificationDataConfigDTO handleSave(@Valid VerificationDataConfigDTO verificationDataConfig)
        throws Exception
    {

        VerificationDataConfig verificationDataConfigEntity = this.verificationDataConfigMapper.verificationDataConfigDTOToEntity(verificationDataConfig);
        VerificationDataConfig savedVerificationDataConfig = this.verificationDataConfigRepository.save(verificationDataConfigEntity);
        return this.verificationDataConfigMapper.toVerificationDataConfigDTO(savedVerificationDataConfig);
    }

    /**
     * @see bw.co.roguesystems.ai.processor.verification.VerificationDataConfigService#remove(String)
     */
    @Override
    protected boolean handleRemove(String id)
        throws Exception
    {

        UUID configId = UUID.fromString(id);
        VerificationDataConfig config = verificationDataConfigRepository.getReferenceById(configId);

        this.verificationDataConfigRepository.delete(config);
        return true;
    }

}