package bw.co.roguesystems.ai;

import org.jspecify.annotations.Nullable;

import java.io.Serializable;


//QueueObject
public record QueueObject (
    // Record attributes
    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.QueueObject.objectId
     */
    java.lang.String objectId,    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.QueueObject.target
     */
    bw.co.roguesystems.ai.TargetEntity target,    /**
     * TODO: Model Documentation for bw.co.roguesystems.ai.QueueObject.targetId
     */
    java.lang.String targetId
) implements Serializable {
}
