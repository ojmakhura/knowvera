package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.logging.Audit;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Set;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

import bw.co.roguesystems.ai.AuditTracker;
import bw.co.roguesystems.ai.TargetEntity;
import bw.co.roguesystems.ai.processor.data.DataFieldDTO;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupApi;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupDTO;
import bw.co.roguesystems.ai.processor.data.DataFieldGroupService;

@RestController
@Tag(name = "Data Field Group", description = "Managing data field group settings.")
public class DataFieldGroupApiImpl implements DataFieldGroupApi {

    private static final Logger logger = LoggerFactory.getLogger(DataFieldGroupApiImpl.class);
    protected final DataFieldGroupService dataFieldGroupService;

    public DataFieldGroupApiImpl(
            DataFieldGroupService dataFieldGroupService) {

        this.dataFieldGroupService = dataFieldGroupService;
    }

    @Override
    @Operation(summary = "Find Data Processor", description = "Get the data processor with the given id")
    public ResponseEntity<DataFieldGroupDTO> findById(String id) throws Exception {
        return ResponseEntity.ok(this.dataFieldGroupService.findById(id));
    }

    @Override
    @Audit(entity = "DATA_FIELD_GROUP", eventLabel = "#id", logData = false)
    public ResponseEntity<Boolean> remove(String id) throws Exception {

        return ResponseEntity.ok(this.dataFieldGroupService.remove(id));
    }

    @Override
    @Audit(entity = "DATA_FIELD_GROUP", logData = false)
    public ResponseEntity<DataFieldGroupDTO> save(@Valid DataFieldGroupDTO fieldGroup) throws Exception {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        AuditTracker.auditTrail(fieldGroup, authentication);

        if (fieldGroup.getGroupFields() != null) {

            for (DataFieldDTO field : fieldGroup.getGroupFields()) {
                AuditTracker.auditTrail(field, authentication);
            }
        }

        return ResponseEntity.ok(this.dataFieldGroupService.save(fieldGroup));
    }

    /**
     * Gets the reference to <code>$serviceRef.daoName</code>.
     * 
     * @return dataFieldGroupService
     */
    protected DataFieldGroupService getDataFieldGroupService() {
        return this.dataFieldGroupService;
    }

    @Override
    public @Nullable ResponseEntity<List<DataFieldGroupDTO>> findByTarget(TargetEntity targetType) throws Exception {
        List<DataFieldGroupDTO> dataFieldGroups = this.dataFieldGroupService.findByTarget(targetType);
        return ResponseEntity.ok(dataFieldGroups);

    }

    @Override
    @Audit(entity = "DATA_FIELD_GROUP", eventLabel = "#id + ' ' + #fieldId", logData = false)
    public ResponseEntity<DataFieldGroupDTO> removeField(String id, String fieldId) throws Exception {

        return ResponseEntity.ok(this.dataFieldGroupService.removeField(id, fieldId));

    }
}