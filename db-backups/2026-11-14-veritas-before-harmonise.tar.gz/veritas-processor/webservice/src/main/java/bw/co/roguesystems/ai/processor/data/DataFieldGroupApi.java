package bw.co.roguesystems.ai.processor.data;

import bw.co.roguesystems.ai.TargetEntity;
import jakarta.validation.Valid;
import java.util.List;
import org.jspecify.annotations.Nullable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 
 * TODO: Model Documentation for bw.co.roguesystems.ai.processor.data.DataFieldGroupApi
 */
@RequestMapping("/data-field-groups")
public interface DataFieldGroupApi {

    @GetMapping(
        value = "/{id}"
    )
    @PreAuthorize(value = "hasAuthority('SCOPE_data-field-groups:view')")
    public ResponseEntity<DataFieldGroupDTO> findById(@PathVariable(name = "id", required = true) String id) throws Exception;

    @GetMapping(
        value = "/target/{targetType}"
    )
    @PreAuthorize(value = "hasAuthority('SCOPE_data-field-groups:list')")
    public @Nullable ResponseEntity<List<DataFieldGroupDTO>> findByTarget(@PathVariable(name = "targetType", required = true) TargetEntity targetType) throws Exception;

    @DeleteMapping(
        value = "/{id}"
    )
    @PreAuthorize(value = "hasAuthority('SCOPE_data-field-groups:delete')")
    public ResponseEntity<Boolean> remove(@PathVariable(name = "id", required = true) String id) throws Exception;

    @DeleteMapping(
        value = "/{id}/field/{fieldId}"
    )
    @PreAuthorize(value = "hasAuthority('SCOPE_data-field-groups:delete')")
    public ResponseEntity<DataFieldGroupDTO> removeField(@PathVariable(name = "id", required = true) String id, @PathVariable(name = "fieldId", required = true) String fieldId) throws Exception;

    @PostMapping(
        
    )
    @PreAuthorize(value = "hasAuthority('SCOPE_data-field-groups:edit')")
    public ResponseEntity<DataFieldGroupDTO> save(@RequestBody(required = true) @Valid DataFieldGroupDTO fieldGroup) throws Exception;
}