package bw.co.roguesystems.ai.processor.verification;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

import bw.co.roguesystems.ai.AuditTracker;
import bw.co.roguesystems.ai.logging.Audit;

@RestController
@Tag(name = "Verification Data Config", description = "Managing the verification data configurations of data processors")
public class VerificationDataConfigApiImpl implements VerificationDataConfigApi {

    private static final Logger logger = LoggerFactory.getLogger(VerificationDataConfigApiImpl.class);
    protected final VerificationDataConfigService verificationDataConfigService;

    public VerificationDataConfigApiImpl(
            VerificationDataConfigService verificationDataConfigService) {

        this.verificationDataConfigService = verificationDataConfigService;
    }

    @Override
    @Operation(summary = "Find Verification Data Config", description = "Get the verification data config with the given id")
    @Audit(entity = "VERIFICATION_DATA_CONFIG", eventLabel = "#id", logData = false)
    public ResponseEntity<VerificationDataConfigDTO> findById(String id) throws Exception {

        logger.debug("Finding verification data config with ID: {}", id);
        return ResponseEntity.ok(verificationDataConfigService.findById(id));
    }

    @Override
    @Operation(summary = "Remove Verification Data Config", description = "Remove the verification data config with the given id")
    @Audit(entity = "VERIFICATION_DATA_CONFIG", eventLabel = "#id", logData = false)
    public ResponseEntity<Boolean> remove(String id) throws Exception {

        logger.debug("Removing verification data config with ID: {}", id);
        return ResponseEntity.ok(verificationDataConfigService.remove(id));

    }

    @Override
    @Operation(summary = "Save Verification Data Config", description = "Save the verification data config")
    @Audit(entity = "VERIFICATION_DATA_CONFIG", eventLabel = "#verificationDataConfig.id", logData = true)
    public ResponseEntity<VerificationDataConfigDTO> save(@Valid VerificationDataConfigDTO verificationDataConfig)
            throws Exception {

        logger.debug("Saving verification data config: {}", verificationDataConfig);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        AuditTracker.auditTrail(verificationDataConfig, authentication);
        throw new UnsupportedOperationException("Not implemented yet");
    }

    /**
     * Gets the reference to <code>$serviceRef.daoName</code>.
     * 
     * @return verificationDataConfigService
     */
    protected VerificationDataConfigService getVerificationDataConfigService() {
        return this.verificationDataConfigService;
    }
}