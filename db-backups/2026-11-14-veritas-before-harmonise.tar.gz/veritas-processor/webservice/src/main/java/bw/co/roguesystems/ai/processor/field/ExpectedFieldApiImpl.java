package bw.co.roguesystems.ai.processor.field;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

import bw.co.roguesystems.ai.AuditTracker;
import bw.co.roguesystems.ai.logging.Audit;

@RestController
@Tag(name = "Expected Fields", description = "Fields expected in data processors.")
public class ExpectedFieldApiImpl implements ExpectedFieldApi {

    private static final Logger logger = LoggerFactory.getLogger(ExpectedFieldApiImpl.class);
    protected final ExpectedFieldService expectedFieldService;

    public ExpectedFieldApiImpl(
            ExpectedFieldService expectedFieldService) {

        this.expectedFieldService = expectedFieldService;
    }

    @Override
    @Operation(summary = "Find Expected Field", description = "Get the expected field with the given id")
    @Audit(entity = "EXPECTED_FIELD", eventLabel = "#id", logData = false)
    public ResponseEntity<ExpectedFieldDTO> findById(String id) throws Exception {

        logger.debug("Finding expected field with ID: {}", id);
        return ResponseEntity.ok(expectedFieldService.findById(id));

    }

    @Override
    @Operation(summary = "Remove Expected Field", description = "Remove the expected field with the given id")
    @Audit(entity = "EXPECTED_FIELD", eventLabel = "#id", logData = false)
    public ResponseEntity<Boolean> remove(String id) throws Exception {
        logger.debug("Removing expected field with ID: {}", id);
        return ResponseEntity.ok(expectedFieldService.remove(id));
    }

    @Override
    @Operation(summary = "Save Expected Field", description = "Save the expected field. If the id is not provided, a new expected field will be created.")
    @Audit(entity = "EXPECTED_FIELD", eventLabel = "#expectedField.id", logData = true)
    public ResponseEntity<ExpectedFieldDTO> save(@Valid ExpectedFieldDTO expectedField) throws Exception {

        logger.debug("Saving expected field: {}", expectedField);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        AuditTracker.auditTrail(expectedField, authentication);

        return ResponseEntity.ok(expectedFieldService.save(expectedField));
    }

    /**
     * Gets the reference to <code>$serviceRef.daoName</code>.
     * 
     * @return expectedFieldService
     */
    protected ExpectedFieldService getExpectedFieldService() {

        logger.debug("Retrieving ExpectedFieldService instance");
        return this.expectedFieldService;
    }

    @Override
    @Operation(summary = "Find Expected Fields by Data Processor", description = "Get the expected fields for the given data processor id")
    @Audit(entity = "EXPECTED_FIELD", logData = false)
    public ResponseEntity<List<ExpectedFieldDTO>> findByDataProcessor(List<String> dataProcessorIds) throws Exception {

        logger.debug("Finding expected fields for data processor IDs: {}", dataProcessorIds);
        return ResponseEntity.ok(expectedFieldService.findByDataProcessor(dataProcessorIds));

    }

    @Override
    @Operation(summary = "Find Expected Fields by Data Processor with Pagination", description = "Get the expected fields for the given data processor id with pagination")
    @Audit(entity = "EXPECTED_FIELD", logData = false)
    public ResponseEntity<Page<ExpectedFieldDTO>> findByDataProcessorPage(List<String> dataProcessorIds,
            Integer pageNumber,
            Integer pageSize) throws Exception {
                
        logger.debug("Finding expected fields for data processor IDs: {}, page: {}, size: {}", dataProcessorIds, pageNumber, pageSize);
        return ResponseEntity.ok(expectedFieldService.findByDataProcessor(dataProcessorIds, pageNumber, pageSize));
    }
}
